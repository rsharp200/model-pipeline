# Random number model package

This model is used to return a random number over a specified range